<h1>CSD 340 Web Development with HTML and CSS</h1>
<h2>Contributors</h2>
<ul>
  <li>Adam Bailey</li>
  <li>Alisa Steensen</li>
</ul>
